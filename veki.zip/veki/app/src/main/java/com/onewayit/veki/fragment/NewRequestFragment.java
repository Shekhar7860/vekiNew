package com.onewayit.veki.fragment;


import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.onewayit.veki.R;
import com.onewayit.veki.activities.MarkerDragActivity;
import com.onewayit.veki.utilities.GPSTracker;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

/**
 * A simple {@link Fragment} subclass.
 */
public class NewRequestFragment extends Fragment implements View.OnClickListener, LocationListener {
    Spinner spinnerDropDown;
    RelativeLayout footer;
    ImageView camera_image, camera_image2, camera_image3, cross, cross2, cross3, iv_gps;
    View view;
    Context context;
    ProgressDialog progressDialog;
    TextView tv_setOnMap;
    EditText et_location;
    String[] cities = {
            "Broken Car",
            "Tyre Issue",
            "Air Problem",
            "Other Issue"

    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.activity_new_request, container, false);
        context = getActivity();
        initViews();
        setOnClickListener();
        // findViewById();
        //setOnClickListener();


        return view;
    }

    private void initViews() {
        cross = view.findViewById(R.id.cross);
        iv_gps = view.findViewById(R.id.iv_gps);
        cross2 = view.findViewById(R.id.cross2);
        cross3 = view.findViewById(R.id.cross3);
        tv_setOnMap = view.findViewById(R.id.tv_setOnMap);
        camera_image = view.findViewById(R.id.camera_image);
        camera_image2 = view.findViewById(R.id.camera_image2);
        camera_image3 = view.findViewById(R.id.camera_image3);
        et_location = view.findViewById(R.id.et_location);
        spinnerDropDown = view.findViewById(R.id.spinner);
        footer = view.findViewById(R.id.footer);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(context, android.
                R.layout.simple_spinner_dropdown_item, cities);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDropDown.setAdapter(adapter);
    }

    private void setOnClickListener() {
        footer.setOnClickListener(this);
        camera_image.setOnClickListener(this);
        camera_image2.setOnClickListener(this);
        camera_image3.setOnClickListener(this);
        cross.setOnClickListener(this);
        cross2.setOnClickListener(this);
        cross3.setOnClickListener(this);
        iv_gps.setOnClickListener(this);
        tv_setOnMap.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.footer:
                Toast.makeText(context, "Please try again....", Toast.LENGTH_SHORT).show();
                ProposalReceivedFragment fragment2 = new ProposalReceivedFragment();
                FragmentManager fragmentManager = getFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.frame_layout, fragment2);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
                break;
            case R.id.camera_image:
                cameraIntent(0);
                break;
            case R.id.camera_image2:
                cameraIntent(1);
                break;
            case R.id.camera_image3:
                cameraIntent(2);
                break;
            case R.id.cross:
                setcamera(3);
                break;
            case R.id.cross2:
                setcamera(2);
                break;
            case R.id.cross3:
                setcamera(1);
                break;
            case R.id.iv_gps: {
                getMyLocation();
                break;
            }
            case R.id.tv_setOnMap: {
                Intent intent = new Intent(context, MarkerDragActivity.class);
                startActivity(intent);
                break;
            }
        }
    }

    private void getMyLocation() {
        checkPermission();
    }

    public void checkPermission() {
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        } else {
            progressDialog = new ProgressDialog(getActivity());
            progressDialog.setMessage("fetching your location");
            progressDialog.show();
            GPSTracker gpsTracker = new GPSTracker(context);
            if (gpsTracker.canGetLocation()) {
                Toast.makeText(context, gpsTracker.getLatitude() + " " + gpsTracker.getLongitude(), Toast.LENGTH_SHORT).show();
                // \n is for new line
                //  Toast.makeText(getApplicationContext(), "Your Location is - \nLat: " + lati + "\nLong: " + longi, Toast.LENGTH_LONG).show();
                double lat = gpsTracker.getLatitude();
                double lng = gpsTracker.getLongitude();

                Geocoder geoCoder = new Geocoder(context, Locale.getDefault());
                StringBuilder builder = new StringBuilder();
                getAddress(lat, lng);

            } else {
                gpsTracker.showSettingsAlert();
            }
        }
    }

    public void getAddress(double lat, double lng) {
        Geocoder geocoder = new Geocoder(context, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(lat, lng, 1);
            Address obj = addresses.get(0);
            String add = "";
            add = add + obj.getLocality();
            add = add + "," + obj.getAdminArea();
            add = add + "," + obj.getCountryName();


            Toast.makeText(context, add, Toast.LENGTH_SHORT).show();
            et_location.setText(add);
            progressDialog.dismiss();
            // Toast.makeText(this, "Address=>" + add,
            // Toast.LENGTH_SHORT).show();

            // TennisAppActivity.showDialog(add);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            Toast.makeText(context, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        //You had this as int. It is advised to have Lat/Loing as double.
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    checkPermission();
                } else {
                    Toast.makeText(context, "Please turn on GPS", Toast.LENGTH_SHORT).show();
                }
                return;
            }
        }
    }


    private void setcamera(Integer a) {
        switch (a) {
            case 3:
                String uri = "@drawable/camera";
                int imageResource = getResources().getIdentifier(uri, null, context.getPackageName());

                // imageview= (ImageView)findViewById(R.id.imageView);
                Drawable res = getResources().getDrawable(imageResource);
                camera_image3.setImageDrawable(res);
                cross.setVisibility(View.GONE);
                break;
            case 2:
                String uri2 = "@drawable/camera";
                int imageResource2 = getResources().getIdentifier(uri2, null, context.getPackageName());
                // imageview= (ImageView)findViewById(R.id.imageView);
                Drawable res2 = getResources().getDrawable(imageResource2);
                camera_image.setImageDrawable(res2);
                cross2.setVisibility(View.GONE);
                break;
            case 1:
                String uri3 = "@drawable/camera";
                int imageResource3 = getResources().getIdentifier(uri3, null, context.getPackageName());
                // imageview= (ImageView)findViewById(R.id.imageView);
                Drawable res3 = getResources().getDrawable(imageResource3);
                camera_image2.setImageDrawable(res3);
                cross3.setVisibility(View.GONE);
                break;
        }
    }

    private void cameraIntent(Integer a) {
        Intent takePicture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(takePicture, a);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent imageReturnedIntent) {
        super.onActivityResult(requestCode, resultCode, imageReturnedIntent);
        if (imageReturnedIntent != null) {
            switch (requestCode) {
                case 0:
                    if (imageReturnedIntent.getExtras() != null) {
                        Bundle extras = imageReturnedIntent.getExtras();
                        Bitmap imageBitmap = (Bitmap) extras.get("data");
                        camera_image.setImageBitmap(imageBitmap);
                        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(200, 200);
                        camera_image.setLayoutParams(layoutParams);
                        cross2.setVisibility(View.VISIBLE);
                    }
                    break;
                case 1:
                    if (imageReturnedIntent.getExtras() != null) {
                        Bundle extras2 = imageReturnedIntent.getExtras();
                        Bitmap imageBitmap2 = (Bitmap) extras2.get("data");
                        camera_image2.setImageBitmap(imageBitmap2);
                        RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(200, 200);
                        camera_image2.setLayoutParams(layoutParams2);
                        cross3.setVisibility(View.VISIBLE);
                    }
                    break;
                case 2:
                    if (imageReturnedIntent.getExtras() != null) {
                        Bundle extras3 = imageReturnedIntent.getExtras();
                        Bitmap imageBitmap3 = (Bitmap) extras3.get("data");
                        camera_image3.setImageBitmap(imageBitmap3);
                        RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams(200, 200);
                        camera_image3.setLayoutParams(layoutParams3);
                        cross.setVisibility(View.VISIBLE);
                    }
                    break;
            }
        }
    }

}
