package com.onewayit.veki.utilities;

public class AppConstant {

    public static final String COUNTRY = "COUNTRY";
    public static final String PhoneNumber = "PhoneNumber";
    public static final String PhoneCode = "PhoneCode";
    public static final String PLUS = "+";
}
