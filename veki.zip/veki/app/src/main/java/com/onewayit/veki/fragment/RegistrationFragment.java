package com.onewayit.veki.fragment;


import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.onewayit.veki.R;
import com.onewayit.veki.activities.HomeActivity;
import com.onewayit.veki.activities.LoginActivity;
import com.onewayit.veki.api.ApiClient;
import com.onewayit.veki.api.ApiInterface;
import com.onewayit.veki.api.apiResponse.registration.RegistrationResponse;
import com.onewayit.veki.utilities.GlobalClass;
import com.onewayit.veki.utilities.Network;

import java.io.IOException;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class RegistrationFragment extends Fragment implements View.OnClickListener, CompoundButton.OnCheckedChangeListener {


    private View view;
    private Context context;
    private ProgressBar progress_bar;
    private GlobalClass globalClass;
    private EditText name, email, mobile_number, password, confirm_password;
    private TextView submit, login, phone;
    private CheckBox service_provider, customer;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_registeration, container, false);
        initializeVariables();
        findViewById();
        setOnClickListener();
        setOnCheckedChangeListener();


        return view;
    }

    private void initializeVariables() {
        context = getActivity();
        globalClass = new GlobalClass();
        ((LoginActivity) Objects.requireNonNull(getActivity())).setHeading("Register");
    }

    private void setOnCheckedChangeListener() {
        service_provider.setOnCheckedChangeListener(this);
        customer.setOnCheckedChangeListener(this);
    }

    private void findViewById() {
        progress_bar = view.findViewById(R.id.progress_bar);
        name = view.findViewById(R.id.name);
        email = view.findViewById(R.id.email);
        mobile_number = view.findViewById(R.id.mobile_number);
        password = view.findViewById(R.id.password);
        confirm_password = view.findViewById(R.id.confirm_password);
        submit = view.findViewById(R.id.submit);
        login = view.findViewById(R.id.login);
        phone = view.findViewById(R.id.phone);
        service_provider = view.findViewById(R.id.service_provider);
        customer = view.findViewById(R.id.customer);
    }

    private void setOnClickListener() {
        submit.setOnClickListener(this);
        login.setOnClickListener(this);
        phone.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.submit:
                Network network = new Network(context);
                if (network.isConnectedToInternet()) {
                    if (validation()) {
                        registration();
                    }
                } else {
                    network.noInternetAlertBox(getActivity(), false);
                }
                break;
            case R.id.login:
                Objects.requireNonNull(getActivity()).getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new EmailLoginFragment(), "EmailLoginFragment").addToBackStack(null).commit();
                break;
            case R.id.phone:
                Objects.requireNonNull(getActivity()).getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new LoginFragment(), "LoginFragment").addToBackStack(null).commit();
                break;
        }
    }

    ///////////Registration API//////////////
    private void registration() {
        progress_bar.setVisibility(View.VISIBLE);
        globalClass.cancelProgressBarInterection(true, getActivity());
        ApiInterface apiService = ApiClient.getClient().create(ApiInterface.class);
        Call<RegistrationResponse> call = apiService.registerUser(getRegistrationParameters());
        Log.e(" Registration url", "" + call.request().url().toString());
        call.enqueue(new Callback<RegistrationResponse>() {
            @Override
            public void onResponse(Call<RegistrationResponse> call, Response<RegistrationResponse> response) {
                progress_bar.setVisibility(View.GONE);
                globalClass.cancelProgressBarInterection(false, getActivity());
                if (response.code() == 200) {
                    Log.e("Registration", "" + globalClass.getJsonString(response.body()));
                    Intent intent = new Intent(context, HomeActivity.class);
                    startActivity(intent);
                    Objects.requireNonNull(getActivity()).finish();

                } else {
                    globalClass.retrofitNetworkErrorHandler(response.code(), view, context);
                }
            }

            @Override
            public void onFailure(Call<RegistrationResponse> call, Throwable t) {
                progress_bar.setVisibility(View.GONE);
                globalClass.cancelProgressBarInterection(false, getActivity());
                Log.e("retrofit error", "" + t.getMessage());
                if (t instanceof IOException) {
                    try {
                        Snackbar.make(view, "Network Failure! Please Check Internet Connection", Snackbar.LENGTH_LONG).show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    }

                }
            }
        });

    }

    ///////////Parameters for login API//////////////
    @SuppressLint("HardwareIds")
    private JsonObject getRegistrationParameters() {
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("name", name.getText().toString().trim());
        jsonObject.addProperty("email", email.getText().toString().trim());
        jsonObject.addProperty("phone", mobile_number.getText().toString().trim());
        if (service_provider.isChecked()) {
            jsonObject.addProperty("role", "3");
        } else {
            jsonObject.addProperty("role", "2");
        }
        jsonObject.addProperty("password", password.getText().toString().trim());
        jsonObject.addProperty("c_password", confirm_password.getText().toString().trim());
        Log.e("registration parameters", jsonObject.toString());
        return jsonObject;
    }

    ///////////////Screen Validation, it will return true if user has fielded all required details/////////////
    private boolean validation() {
        if (!service_provider.isChecked() && !customer.isChecked()) {
            Snackbar.make(view, "Please Select Role", Snackbar.LENGTH_LONG).show();
            return false;
        } else if (name.getText().toString().isEmpty()) {
            Snackbar.make(view, "Please Enter Name", Snackbar.LENGTH_LONG).show();
            return false;
        } else if (email.getText().toString().isEmpty()) {
            Snackbar.make(view, "Please Enter Email Id", Snackbar.LENGTH_LONG).show();
            return false;
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email.getText().toString()).matches()) {
            Snackbar.make(view, "Please Enter a Valid Email Id", Snackbar.LENGTH_LONG).show();
            return false;
        } else if (mobile_number.getText().toString().isEmpty()) {
            Snackbar.make(view, "Please Enter Mobile Number", Snackbar.LENGTH_LONG).show();
            return false;
        } else if (mobile_number.getText().toString().length() < 10) {
            Snackbar.make(view, "Please Enter a Valid Mobile Number", Snackbar.LENGTH_LONG).show();
            return false;
        } else if (password.getText().toString().isEmpty()) {
            Snackbar.make(view, "Please Enter Password", Snackbar.LENGTH_LONG).show();
            return false;
        } else if (confirm_password.getText().toString().isEmpty()) {
            Snackbar.make(view, "Please Enter Confirm Password", Snackbar.LENGTH_LONG).show();
            return false;
        } else if (!password.getText().toString().equalsIgnoreCase(confirm_password.getText().toString())) {
            Snackbar.make(view, "Password and Confirm Password does not match", Snackbar.LENGTH_LONG).show();
            return false;
        }

        return true;
    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        switch (compoundButton.getId()) {
            case R.id.service_provider:
                if (b) {
                    customer.setChecked(false);
                }
                break;
            case R.id.customer:
                if (b) {
                    service_provider.setChecked(false);
                }
                break;

        }


    }
}
