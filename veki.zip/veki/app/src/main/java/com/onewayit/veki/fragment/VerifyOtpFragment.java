package com.onewayit.veki.fragment;


import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.onewayit.veki.R;
import com.onewayit.veki.activities.LoginActivity;
import com.onewayit.veki.api.ApiClient;
import com.onewayit.veki.api.ApiInterface;
import com.onewayit.veki.api.apiResponse.otp.VerifyOtpResponse;
import com.onewayit.veki.utilities.GlobalClass;

import java.io.IOException;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class VerifyOtpFragment extends Fragment implements View.OnClickListener, View.OnKeyListener {

    private View view;
    private Context context;
    private EditText digit_one, digit_two, digit_three, digit_four;
    private TextView mobile_number;
    private ProgressBar progress_bar;
    private GlobalClass globalClass;
    private String mobileNumber = "", otp = "";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_verify_otp, container, false);
        context = getActivity();
        initializeVariables();
        findViewById();
        setOnClickListener();
        setOnKeyListener();
        textWatcher();

        return view;
    }

    private void initializeVariables() {
        globalClass = new GlobalClass();
        mobileNumber = Objects.requireNonNull(getArguments()).getString("mobile_number");
        otp = Objects.requireNonNull(getArguments()).getString("otp");
        ((LoginActivity) Objects.requireNonNull(getActivity())).setHeading("Verify");
    }

    private void findViewById() {
        digit_one = view.findViewById(R.id.digit_one);
        digit_two = view.findViewById(R.id.digit_two);
        digit_three = view.findViewById(R.id.digit_three);
        digit_four = view.findViewById(R.id.digit_four);
        progress_bar = view.findViewById(R.id.progress_bar);
        mobile_number = view.findViewById(R.id.mobile_number);
        mobile_number.setText(("Sent to +91" + mobileNumber));
    }

    private void setOnClickListener() {

    }

    private void setOnKeyListener() {
        digit_two.setOnKeyListener(this);
        digit_three.setOnKeyListener(this);
        digit_four.setOnKeyListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {

        }
    }

    @Override
    public boolean onKey(View view, int keyCode, KeyEvent keyEvent) {
        switch (view.getId()) {

            case R.id.digit_two:
                if (keyCode == KeyEvent.KEYCODE_DEL && digit_two.getText().toString().trim().isEmpty() && keyEvent.getAction() == KeyEvent.ACTION_DOWN) {
                    digit_one.requestFocus();
                }
                break;
            case R.id.digit_three:
                if (keyCode == KeyEvent.KEYCODE_DEL && digit_three.getText().toString().trim().isEmpty() && keyEvent.getAction() == KeyEvent.ACTION_DOWN) {
                    digit_two.requestFocus();
                }

                break;
            case R.id.digit_four:
                if (keyCode == KeyEvent.KEYCODE_DEL && digit_four.getText().toString().isEmpty() && keyEvent.getAction() == KeyEvent.ACTION_DOWN) {
                    digit_three.requestFocus();
                }
                break;
        }
        return false;
    }


    private void textWatcher() {
        digit_one.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int length) {
                if (!digit_one.getText().toString().isEmpty() && !digit_two.getText().toString().isEmpty() && !digit_three.getText().toString().isEmpty() && !digit_four.getText().toString().isEmpty()) {
                    verifyOtp();
                } else {
                    if (length == 1) {
                        digit_two.requestFocus();
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        digit_two.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int length) {
                if (!digit_one.getText().toString().isEmpty() && !digit_two.getText().toString().isEmpty() && !digit_three.getText().toString().isEmpty() && !digit_four.getText().toString().isEmpty()) {
                    verifyOtp();
                } else {
                    if (length == 1) {
                        digit_three.requestFocus();
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        digit_three.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int length) {
                if (!digit_one.getText().toString().isEmpty() && !digit_two.getText().toString().isEmpty() && !digit_three.getText().toString().isEmpty() && !digit_four.getText().toString().isEmpty()) {
                    verifyOtp();
                } else {
                    if (length == 1) {
                        digit_four.requestFocus();
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        digit_four.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int length) {
                if (length == 1) {
                    if (!digit_one.getText().toString().isEmpty() && !digit_two.getText().toString().isEmpty() && !digit_three.getText().toString().isEmpty() && !digit_four.getText().toString().isEmpty()) {
                        verifyOtp();
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }


    ///////////OTP API//////////////
    private void verifyOtp() {
        progress_bar.setVisibility(View.VISIBLE);
        globalClass.cancelProgressBarInterection(true, getActivity());
        ApiInterface apiService = ApiClient.getClient().create(ApiInterface.class);
        Call<VerifyOtpResponse> call = apiService.verifyOtp(getVerifyOtpParameters());
        Log.e(" verify Otp url", "" + call.request().url().toString());
        call.enqueue(new Callback<VerifyOtpResponse>() {
            @Override
            public void onResponse(Call<VerifyOtpResponse> call, Response<VerifyOtpResponse> response) {
                progress_bar.setVisibility(View.GONE);
                globalClass.cancelProgressBarInterection(false, getActivity());
                if (response.code() == 200) {
                    Log.e("verify Otp", "" + globalClass.getJsonString(response.body()));
                    globalClass.closeKeyBoard(getActivity());
                    Bundle bundle = new Bundle();
                    bundle.putString("mobile_number", mobileNumber);
                    RoleFragment roleFragment = new RoleFragment();
                    roleFragment.setArguments(bundle);
                    Objects.requireNonNull(getActivity()).getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, roleFragment, "RoleFragment").addToBackStack(null).commit();

                } else {
                    globalClass.retrofitNetworkErrorHandler(response.code(), view, context);
                }
            }

            @Override
            public void onFailure(Call<VerifyOtpResponse> call, Throwable t) {
                progress_bar.setVisibility(View.GONE);
                globalClass.cancelProgressBarInterection(false, getActivity());
                Log.e("retrofit error", "" + t.getMessage());
                if (t instanceof IOException) {
                    try {
                        Snackbar.make(view, "Network Failure! Please Check Internet Connection", Snackbar.LENGTH_LONG).show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    }

                }
            }
        });

    }

    ///////////Parameters for login API//////////////
    @SuppressLint("HardwareIds")
    private JsonObject getVerifyOtpParameters() {
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("phone", "" + mobileNumber);
        jsonObject.addProperty("otp", "" + otp);
        jsonObject.addProperty("device_id", android.provider.Settings.Secure.getString(context.getContentResolver(), android.provider.Settings.Secure.ANDROID_ID));
        jsonObject.addProperty("device_token", "43523");
        jsonObject.addProperty("device_type", "android");
        Log.e("verify Otp parameters", jsonObject.toString());
        return jsonObject;
    }


}
