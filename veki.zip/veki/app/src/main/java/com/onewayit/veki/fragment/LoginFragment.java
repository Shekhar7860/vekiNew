package com.onewayit.veki.fragment;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.google.gson.JsonObject;
import com.onewayit.veki.R;
import com.onewayit.veki.activities.HomeActivity;
import com.onewayit.veki.activities.LoginActivity;
import com.onewayit.veki.api.ApiClient;
import com.onewayit.veki.api.ApiInterface;
import com.onewayit.veki.api.apiResponse.otp.OtpResponse;
import com.onewayit.veki.utilities.GlobalClass;
import com.onewayit.veki.utilities.Network;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Arrays;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginFragment extends Fragment implements View.OnClickListener {

    CallbackManager callbackManager = CallbackManager.Factory.create();
    private View view;
    private Context context;
    private TextView login, register, request_otp, facebook;
    private ProgressBar progress_bar;
    private EditText mobile_number;
    private GlobalClass globalClass;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_login, container, false);
        initializeVariables();
        findViewById();
        setOnClickListener();
        return view;

    }

    @Override
    public void onResume() {
        super.onResume();
        onBackPressed();
    }

    private void initializeVariables() {
        context = getActivity();
        globalClass = new GlobalClass();
        ((LoginActivity) Objects.requireNonNull(getActivity())).setHeading("");
        FacebookSdk.sdkInitialize(getActivity());
    }

    private void findViewById() {
        login = view.findViewById(R.id.login);
        register = view.findViewById(R.id.register);
        progress_bar = view.findViewById(R.id.progress_bar);
        request_otp = view.findViewById(R.id.request_otp);
        mobile_number = view.findViewById(R.id.mobile_number);
        facebook = view.findViewById(R.id.facebook);
    }

    private void setOnClickListener() {
        login.setOnClickListener(this);
        facebook.setOnClickListener(this);
        register.setOnClickListener(this);
        request_otp.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.facebook:
                LoginManager.getInstance().logInWithReadPermissions(getActivity(), Arrays.asList("public_profile", "email"));
                LoginManager.getInstance().registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
                    @Override
                    public void onSuccess(LoginResult loginResult) {
                        //   Toast.makeText(getActivity(), "its working",
                        //       Toast.LENGTH_LONG).show();
                        GraphRequest request = GraphRequest.newMeRequest(
                                loginResult.getAccessToken(),
                                new GraphRequest.GraphJSONObjectCallback() {
                                    @Override
                                    public void onCompleted(JSONObject object, GraphResponse response) {
                                        Log.v("LoginActivity", response.toString());

                                        try {
                                            String name = object.getString("name");
                                            // Toast.makeText(getActivity(), name,
                                            //        Toast.LENGTH_LONG).show();
                                            Intent intent = new Intent(getActivity(), HomeActivity.class);
                                            intent.putExtra("MyClass", object.toString());
                                            startActivity(intent);
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                });
                        request.executeAsync();
                    }


                    @Override
                    public void onCancel() {

                    }

                    @Override
                    public void onError(FacebookException e) {
                        Toast.makeText(getActivity(), e.toString(),
                                Toast.LENGTH_LONG).show();
                    }
                });
                break;
            case R.id.login:
                Objects.requireNonNull(getActivity()).getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new EmailLoginFragment(), "EmailLoginFragment").addToBackStack(null).commit();
                break;
            case R.id.register:
                goToRegisterationFragment();
                break;
            case R.id.request_otp:
                Network network = new Network(context);
                if (network.isConnectedToInternet()) {
                    if (validation()) {
                        generateOtp();
                    }
                } else {
                    network.noInternetAlertBox(getActivity(), false);
                }
                break;

        }


    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        callbackManager.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void goToRegisterationFragment() {
        Objects.requireNonNull(getActivity()).getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new RegistrationFragment(), "RegistrationFragment").addToBackStack(null).commit();
    }

    private void onBackPressed() {
        Objects.requireNonNull(getView()).setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {

                    Objects.requireNonNull(getActivity()).onBackPressed();

                    return true;

                }

                return false;
            }
        });
    }

    ///////////////Screen Validation, it will return true if user has fielded all required details/////////////
    private boolean validation() {
        if (mobile_number.getText().toString().isEmpty()) {
            Snackbar.make(view, "Please Enter Mobile Number", Snackbar.LENGTH_LONG).show();
            return false;
        } else if (mobile_number.getText().toString().length() < 10) {
            Snackbar.make(view, "Please Enter a Valid Mobile Number", Snackbar.LENGTH_LONG).show();
            return false;
        }

        return true;
    }

    ///////////OTP API//////////////
    private void generateOtp() {
        progress_bar.setVisibility(View.VISIBLE);
        globalClass.cancelProgressBarInterection(true, getActivity());
        ApiInterface apiService = ApiClient.getClient().create(ApiInterface.class);
        Call<OtpResponse> call = apiService.generateOtp(getOtpParameters());
        Log.e(" Otp url", "" + call.request().url().toString());
        call.enqueue(new Callback<OtpResponse>() {
            @Override
            public void onResponse(Call<OtpResponse> call, Response<OtpResponse> response) {
                progress_bar.setVisibility(View.GONE);
                globalClass.cancelProgressBarInterection(false, getActivity());
                if (response.code() == 200) {
                    Log.e("Otp", "" + globalClass.getJsonString(response.body()));
                    Bundle bundle = new Bundle();
                    bundle.putString("mobile_number", mobile_number.getText().toString());
                    bundle.putString("otp", "" + Objects.requireNonNull(response.body()).getOtpNumber().toString());
                    VerifyOtpFragment verifyOtpFragment = new VerifyOtpFragment();
                    verifyOtpFragment.setArguments(bundle);

                    Objects.requireNonNull(getActivity()).getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, verifyOtpFragment, "VerifyOtpFragment").addToBackStack(null).commit();

                } else {
                    globalClass.retrofitNetworkErrorHandler(response.code(), view, context);
                }
            }

            @Override
            public void onFailure(Call<OtpResponse> call, Throwable t) {
                progress_bar.setVisibility(View.GONE);
                globalClass.cancelProgressBarInterection(false, getActivity());
                Log.e("retrofit error", "" + t.getMessage());
                if (t instanceof IOException) {
                    try {
                        Snackbar.make(view, "Network Failure! Please Check Internet Connection", Snackbar.LENGTH_LONG).show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    }

                }
            }
        });

    }

    ///////////Parameters for login API//////////////
    @SuppressLint("HardwareIds")
    private JsonObject getOtpParameters() {
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("phone", mobile_number.getText().toString().trim());
        Log.e("Otp parameters", jsonObject.toString());
        return jsonObject;
    }


}
