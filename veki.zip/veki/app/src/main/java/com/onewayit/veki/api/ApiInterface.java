package com.onewayit.veki.api;

import com.google.gson.JsonObject;
import com.onewayit.veki.api.apiResponse.emailLogin.LoginResponse;
import com.onewayit.veki.api.apiResponse.otp.OtpResponse;
import com.onewayit.veki.api.apiResponse.otp.VerifyOtpResponse;
import com.onewayit.veki.api.apiResponse.registration.RegistrationResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface ApiInterface {

    @POST("login")
    Call<LoginResponse> loginUser(@Body JsonObject jsonObject);

    @POST("register")
    Call<RegistrationResponse> registerUser(@Body JsonObject jsonObject);

    @POST("send/otp")
    Call<OtpResponse> generateOtp(@Body JsonObject jsonObject);

    @POST("verified/otp")
    Call<VerifyOtpResponse> verifyOtp(@Body JsonObject jsonObject);


}
