package com.onewayit.veki.activities;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.CardView;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.FragmentActivity;

import com.crystal.crystalrangeseekbar.interfaces.OnRangeSeekbarChangeListener;
import com.crystal.crystalrangeseekbar.interfaces.OnRangeSeekbarFinalValueListener;
import com.crystal.crystalrangeseekbar.widgets.CrystalRangeSeekbar;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.onewayit.veki.R;
import com.onewayit.veki.fragment.MarkerDetailFragment;
import com.onewayit.veki.fragment.MyProposals;
import com.onewayit.veki.fragment.MyRequests;
import com.onewayit.veki.fragment.MyServices;
import com.onewayit.veki.fragment.NewRequestFragment;
import com.onewayit.veki.fragment.NotificationFragment;
import com.onewayit.veki.fragment.ProfileFragment;

import java.util.Objects;

import de.hdodenhof.circleimageview.CircleImageView;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener, GoogleMap.OnMapClickListener, View.OnClickListener, NavigationView.OnNavigationItemSelectedListener {

    TextView tv_help, view_details;
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    ImageView iv_menu, filter, alert;
    CardView card1;
    RelativeLayout marker_details, rl_distance_bar;
    boolean doubleBackToExitPressedOnce = false;
    private GoogleMap mMap;

    public static Bitmap createDrawableFromView(Context context, View view) {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((Activity) context).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        view.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        view.measure(displayMetrics.widthPixels, displayMetrics.heightPixels);
        view.layout(0, 0, displayMetrics.widthPixels, displayMetrics.heightPixels);
        view.buildDrawingCache();
        Bitmap bitmap = Bitmap.createBitmap(view.getMeasuredWidth(), view.getMeasuredHeight(), Bitmap.Config.ARGB_8888);

        Canvas canvas = new Canvas(bitmap);
        view.draw(canvas);

        return bitmap;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        findViewIds();
        checkPermission();
        setOnClickListeners();
        setDistanceListener();
    }

    private void setDistanceListener() {
        // get seekbar from view
        final CrystalRangeSeekbar rangeSeekbar = findViewById(R.id.rangeSeekbar3);

// get min and max text view
        final TextView tvMin = findViewById(R.id.tv_min1);
        final TextView tvMax = findViewById(R.id.tv_max1);

// set listener
        rangeSeekbar.setOnRangeSeekbarChangeListener(new OnRangeSeekbarChangeListener() {
            @Override
            public void valueChanged(Number minValue, Number maxValue) {
                tvMin.setText(minValue + "-");
                tvMax.setText(maxValue + " km");
            }
        });

// set final value listener
        rangeSeekbar.setOnRangeSeekbarFinalValueListener(new OnRangeSeekbarFinalValueListener() {
            @Override
            public void finalValue(Number minValue, Number maxValue) {
                tvMin.setText(minValue + "-");
                tvMax.setText(maxValue + " km");
            }
        });
    }

    private void setOnClickListeners() {
        card1.setOnClickListener(this);
        tv_help.setOnClickListener(this);
        filter.setOnClickListener(this);
        iv_menu.setOnClickListener(this);
        alert.setOnClickListener(this);
        view_details.setOnClickListener(this);
        navigationView.setNavigationItemSelectedListener(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            drawerLayout.setOnScrollChangeListener(new View.OnScrollChangeListener() {
                @Override
                public void onScrollChange(View v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                    drawerLayout.bringToFront();
                    drawerLayout.requestLayout();
                }
            });
        }
    }

    private void findViewIds() {
        navigationView = findViewById(R.id.nav_view);
        tv_help = findViewById(R.id.tv_help);
        drawerLayout = findViewById(R.id.drawer_layout);
        tv_help.setVisibility(View.VISIBLE);
        marker_details = findViewById(R.id.marker_details);
        rl_distance_bar = findViewById(R.id.rl_distance_bar);
        view_details = findViewById(R.id.view_details);
        filter = findViewById(R.id.filter);
        card1 = findViewById(R.id.card1);
        iv_menu = findViewById(R.id.menu);
        alert = findViewById(R.id.alert);
    }

    public void checkPermission() {
        if (ActivityCompat.checkSelfPermission(MapsActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(MapsActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MapsActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        } else {
            SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                    .findFragmentById(R.id.map);


            mapFragment.getMapAsync(this);
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        mMap.setMyLocationEnabled(true);
        addMarkers();
        mMap.setOnMarkerClickListener(this);
        mMap.setOnMapClickListener(this);
    }

    private void addMarkers() {
        LatLng latLng1 = new LatLng(30.7017322, 76.722553);
        LatLng latLng2 = new LatLng(30.69241, 76.7318493);
        LatLng latLng3 = new LatLng(30.7567589, 76.7164291);
        LatLng latLng4 = new LatLng(30.8050769, 76.7269012);
        View marker = ((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.custom_marker_layout, null);
        CircleImageView iv_user = marker.findViewById(R.id.iv_user);
        iv_user.setImageDrawable(getResources().getDrawable(R.drawable.user1));
        View marker1 = ((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.custom_marker_layout, null);
        CircleImageView iv_user1 = marker1.findViewById(R.id.iv_user);
        iv_user1.setImageDrawable(getResources().getDrawable(R.drawable.user2));
        Marker m1 = mMap.addMarker(new MarkerOptions()
                .position(latLng1)
                .icon(BitmapDescriptorFactory.fromBitmap(createDrawableFromView(this, marker)))
                .title("Mohali 7 Phase"));
        Marker m2 = mMap.addMarker(new MarkerOptions()
                .position(latLng2)
                .icon(BitmapDescriptorFactory.fromBitmap(createDrawableFromView(this, marker1)))
                .title("11 Phase bypass"));
        Marker m3 = mMap.addMarker(new MarkerOptions()
                .position(latLng3)
                .icon(BitmapDescriptorFactory.fromBitmap(createDrawableFromView(this, marker)))
                .title("11 Phase bypass"));
        Marker m4 = mMap.addMarker(new MarkerOptions()
                .position(latLng4)
                .icon(BitmapDescriptorFactory.fromBitmap(createDrawableFromView(this, marker1)))
                .title("11 Phase bypass"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng1));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng3, 12.0f));

        // CustomInfoWindowGoogleMap customInfoWindow = new CustomInfoWindowGoogleMap(this);
        // mMap.setInfoWindowAdapter(customInfoWindow);
        mMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
            @Override
            public void onInfoWindowClick(Marker marker) {
                getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new MarkerDetailFragment(), "markerFragment").addToBackStack(null).commit();
                tv_help.setVisibility(View.GONE);
                marker_details.setVisibility(View.GONE);
            }
        });


    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                            .findFragmentById(R.id.map);
                    mapFragment.getMapAsync(this);

                } else {
                    this.finish();
                }
                return;
            }
        }
    }

    @Override
    public boolean onMarkerClick(Marker marker) {
        marker.showInfoWindow();
        marker_details.setVisibility(View.VISIBLE);
        rl_distance_bar.setVisibility(View.GONE);
        return false;
    }

    @Override
    public void onMapClick(LatLng latLng) {
        marker_details.setVisibility(View.GONE);
        rl_distance_bar.setVisibility(View.GONE);
        tv_help.setVisibility(View.VISIBLE);
    }

    @Override
    public void onClick(View v) {
        marker_details.setVisibility(View.GONE);
        tv_help.setVisibility(View.GONE);
        switch (v.getId()) {
            case R.id.view_details: {
                getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new MarkerDetailFragment(), "markerFragment").addToBackStack(null).commit();
                card1.setVisibility(View.GONE);
                break;
            }
            case R.id.tv_help: {
                getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new NewRequestFragment(), "myProfile").addToBackStack(null).commit();
                card1.setVisibility(View.GONE);
                tv_help.setVisibility(View.GONE);
                break;
            }

            case R.id.menu: {
                drawerLayout.openDrawer(Gravity.START);
                break;
            }
            case R.id.alert: {
                getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new NotificationFragment(), "myProfile").addToBackStack(null).commit();
                card1.setVisibility(View.GONE);
                break;
            }
            case R.id.filter: {
                rl_distance_bar.setVisibility(View.VISIBLE);
                break;
            }
//            case R.id.btn_setLoc:{
//                btn_setLoc.setVisibility(View.VISIBLE);
//                tv_help.setVisibility(View.VISIBLE);
//                Intent intent=new Intent(this,MarkerDragActivity.class);
//                startActivity(intent);
//                break;
//            }
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

        navigationView.getMenu().findItem(menuItem.getItemId()).setCheckable(true).setChecked(true);
        Intent intent;
        marker_details.setVisibility(View.GONE);
        card1.setVisibility(View.GONE);
        switch (menuItem.getItemId()) {
            case R.id.Home: {
                //do somthing
                tv_help.setVisibility(View.GONE);
                intent = new Intent(this, MapsActivity.class);
                startActivity(intent);
                Objects.requireNonNull(this).finish();
                break;
            }
            case R.id.MyRequests: {
                tv_help.setVisibility(View.GONE);
                getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new MyRequests(), "requestFragment").addToBackStack(null).commit();
                //do somthing
                break;
            }
            case R.id.MyServices: {
                tv_help.setVisibility(View.GONE);
                getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new MyServices(), "requestFragment").addToBackStack(null).commit();
                //do somthing
                break;
            }
            case R.id.Proposal: {
                tv_help.setVisibility(View.GONE);
                getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new MyProposals(), "requestFragment").addToBackStack(null).commit();
                //do somthing
                break;
            }
            case R.id.Profile: {
                tv_help.setVisibility(View.GONE);
                getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new ProfileFragment(), "myProfile").addToBackStack(null).commit();
                //do somthing
                break;
            }
            case R.id.Support: {
                Intent emailIntent = new Intent(Intent.ACTION_SEND);
                emailIntent.setType("text/plain");
                startActivity(emailIntent);
                //do somthing
                break;
            }
            case R.id.signout: {
                //do somthing
                tv_help.setVisibility(View.GONE);
                intent = new Intent(this, MapsActivity.class);
                startActivity(intent);
                Objects.requireNonNull(this).finish();
                break;
            }
            case R.id.signin: {
                //do somthing
                intent = new Intent(this, LoginActivity.class);
                startActivity(intent);
                break;
            }

        }
        //close navigation drawer
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {

        getSupportFragmentManager().popBackStackImmediate();
        if (getSupportFragmentManager().getBackStackEntryCount() < 1) {
            card1.setVisibility(View.VISIBLE);
            tv_help.setVisibility(View.VISIBLE);
            if (doubleBackToExitPressedOnce) {
                super.onBackPressed();
                return;
            }

            this.doubleBackToExitPressedOnce = true;
            Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

            new Handler().postDelayed(new Runnable() {

                @Override
                public void run() {
                    doubleBackToExitPressedOnce = false;
                }
            }, 2000);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

    }
}
