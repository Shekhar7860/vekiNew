package com.onewayit.veki.fragment;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.onewayit.veki.R;
import com.onewayit.veki.activities.LoginActivity;
import com.onewayit.veki.activities.MapsActivity;
import com.onewayit.veki.api.ApiClient;
import com.onewayit.veki.api.ApiInterface;
import com.onewayit.veki.api.apiResponse.emailLogin.LoginResponse;
import com.onewayit.veki.utilities.GlobalClass;
import com.onewayit.veki.utilities.Network;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class EmailLoginFragment extends Fragment implements View.OnClickListener {
    private View view;
    private Context context;
    private TextView sign_up, submit;
    private ProgressBar progress_bar;
    private EditText email, password;
    private GlobalClass globalClass;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_email_login, container, false);
        initializeVariables();
        findViewById();
        setOnClickListener();
        return view;
    }


    private void initializeVariables() {
        context = getActivity();
        globalClass = new GlobalClass();
        ((LoginActivity) Objects.requireNonNull(getActivity())).setHeading("Log In");
    }

    private void findViewById() {
        sign_up = view.findViewById(R.id.sign_up);
        progress_bar = view.findViewById(R.id.progress_bar);
        email = view.findViewById(R.id.email);
        password = view.findViewById(R.id.password);
        submit = view.findViewById(R.id.submit);
    }

    private void setOnClickListener() {
        sign_up.setOnClickListener(this);
        submit.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.sign_up:
                goToRegisterationFragment();
                break;
            case R.id.submit:
                Network network = new Network(context);
                if (network.isConnectedToInternet()) {
                    if (validation()) {
                        login();
                    }
                } else {
                    network.noInternetAlertBox(getActivity(), false);
                }
                break;
        }
    }

    private void goToRegisterationFragment() {
        Objects.requireNonNull(getActivity()).getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new RegistrationFragment(), "RegistrationFragment").addToBackStack(null).commit();
    }


    ///////////login API//////////////
    private void login() {
        progress_bar.setVisibility(View.VISIBLE);
        globalClass.cancelProgressBarInterection(true, getActivity());
        ApiInterface apiService = ApiClient.getClient().create(ApiInterface.class);
        Call<LoginResponse> call = apiService.loginUser(getLoginParameters());
        Log.e(" Login url", "" + call.request().url().toString());
        call.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                progress_bar.setVisibility(View.GONE);
                globalClass.cancelProgressBarInterection(false, getActivity());
                if (response.code() == 200) {
                    Log.e("LoginResponse", "" + globalClass.getJsonString(response.body()));
                    Intent intent = new Intent(context, MapsActivity.class);
                    startActivity(intent);
                    Objects.requireNonNull(getActivity()).finish();


                } else if (response.code() == 409 || response.code() == 404) {
                    try {
                        JSONObject jsonObject = new JSONObject(globalClass.getErrorResponseBody(response.errorBody()));
                        if (jsonObject.has("error_message") && !jsonObject.getString("error_message").isEmpty()) {
                            try {
                                Snackbar.make(view, jsonObject.getString("error_message"), Snackbar.LENGTH_LONG).show();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();
                            }

                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } else {
                    globalClass.retrofitNetworkErrorHandler(response.code(), view, context);
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                progress_bar.setVisibility(View.GONE);
                globalClass.cancelProgressBarInterection(false, getActivity());
                Log.e("retrofit error", "" + t.getMessage());
                if (t instanceof IOException) {
                    try {
                        Snackbar.make(view, "Network Failure! Please Check Internet Connection", Snackbar.LENGTH_LONG).show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    }

                }
            }
        });

    }

    ///////////Parameters for login API//////////////
    @SuppressLint("HardwareIds")
    private JsonObject getLoginParameters() {
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("email", email.getText().toString().trim());
        jsonObject.addProperty("password", password.getText().toString().trim());
        jsonObject.addProperty("device_id", android.provider.Settings.Secure.getString(context.getContentResolver(), android.provider.Settings.Secure.ANDROID_ID));
        jsonObject.addProperty("device_token", "235234");
        jsonObject.addProperty("device_type", "android");
        Log.e("login parameters", jsonObject.toString());
        return jsonObject;
    }

    ///////////////Screen Validation, it will return true if user has fielded all required details/////////////
    private boolean validation() {
        if (email.getText().toString().isEmpty()) {
            Snackbar.make(view, "Please Enter Email Id", Snackbar.LENGTH_LONG).show();
            return false;
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email.getText().toString()).matches()) {
            Snackbar.make(view, "Please Enter a Valid Email Id", Snackbar.LENGTH_LONG).show();
            return false;
        } else if (password.getText().toString().isEmpty()) {
            Snackbar.make(view, "Please Enter Password", Snackbar.LENGTH_LONG).show();
            return false;
        }

        return true;
    }

}
