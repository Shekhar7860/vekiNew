package com.onewayit.veki.fragment;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.onewayit.veki.GetterSetter.ServiceData;
import com.onewayit.veki.R;
import com.onewayit.veki.activities.HomeActivity;
import com.onewayit.veki.activities.MapsActivity;
import com.onewayit.veki.utilities.MultiSelectionSpinner;
import com.onewayit.veki.utilities.Network;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static android.app.Activity.RESULT_OK;

/**
 * A simple {@link Fragment} subclass.
 */
public class ProfileFragment extends Fragment implements View.OnClickListener, MultiSelectionSpinner.OnMultipleItemsSelectedListener {
    MultiSelectionSpinner multiSelectionSpinner;
    ArrayList<ServiceData> serviceData;
    LinearLayout services_lay;
    private View view;
    private Context context;
    private EditText et_mobile_number, name, email;
    private TextView submit, tv_etProfile, tv_cancel;
    private ImageView image, back_button_home_activity, iv_add;
    private Button bt;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_profile, container, false);
        context = getActivity();
        initializeVariables();
        findViewById();
        setOnClickListener();
        addServices();
        disableEdit();
        return view;
    }

    private void initializeVariables() {
        //((MapsActivity) Objects.requireNonNull(getActivity())).setHeading("Profile");
        serviceData = new ArrayList<>();
    }

    private void findViewById() {

        name = view.findViewById(R.id.name);
        image = view.findViewById(R.id.image);
        email = view.findViewById(R.id.email);
        tv_cancel = view.findViewById(R.id.tv_cancel);
        tv_etProfile = view.findViewById(R.id.tv_etProfile);
        et_mobile_number = view.findViewById(R.id.et_mobile_number);
        submit = view.findViewById(R.id.submit);
        iv_add = view.findViewById(R.id.iv_add);
        services_lay = view.findViewById(R.id.services_lay);
        back_button_home_activity = view.findViewById(R.id.back_button_home_activity);

        String[] array = {"Car Wash", "Select multiple services", "Tyre Puncture", "Pollution Check", "Battery Problem", "Tube Replacement", "Engine Repair"};
        multiSelectionSpinner = view.findViewById(R.id.mySpinner);
        multiSelectionSpinner.setItems(array);
        multiSelectionSpinner.setSelection(new int[]{1});

//        mobile_number = view.findViewById(R.id.mobile_number);
//        mobile_number.setText((Objects.requireNonNull(getArguments()).getString("mobile_number")));
    }

    public void addServices() {
        LinearLayout.LayoutParams lparams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        TextView tv = new TextView(context);
        tv.setLayoutParams(lparams);
        tv.setBackgroundResource(R.drawable.circular_services_back);
        tv.setPadding(20, 20, 20, 20);
        tv.setText("Car Accident");
        tv.setTypeface(tv.getTypeface(), Typeface.BOLD);
        this.services_lay.addView(tv);
        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle data = new Bundle();
                data.putString("action", "Update Service");
                AddUpdateServicesFragment fragment2 = new AddUpdateServicesFragment();
                fragment2.setArguments(data);
                FragmentManager fragmentManager = getFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.replace(R.id.frame_layout, fragment2);
                fragmentTransaction.commit();
            }
        });
    }


    private void setOnClickListener() {
        submit.setOnClickListener(this);

        image.setOnClickListener(this);
        iv_add.setOnClickListener(this);
        tv_etProfile.setOnClickListener(this);
        tv_cancel.setOnClickListener(this);
        // bt.setOnClickListener(this);
        multiSelectionSpinner.setListener(this);
        back_button_home_activity.setOnClickListener(this);
    }

    public void enableEdit() {
        submit.setOnClickListener(this);
        submit.setVisibility(View.VISIBLE);
        iv_add.setOnClickListener(this);
        multiSelectionSpinner.setListener(this);
        image.setOnClickListener(this);
        name.setEnabled(true);
        email.setEnabled(true);
        et_mobile_number.setEnabled(true);
        tv_etProfile.setVisibility(View.GONE);
        tv_cancel.setVisibility(View.VISIBLE);
    }

    public void disableEdit() {
        submit.setOnClickListener(null);
        submit.setVisibility(View.GONE);
        iv_add.setOnClickListener(null);
        multiSelectionSpinner.setListener(null);
        image.setOnClickListener(null);
        name.setEnabled(false);
        email.setEnabled(false);
        tv_etProfile.setVisibility(View.VISIBLE);
        tv_cancel.setVisibility(View.GONE);
        et_mobile_number.setEnabled(false);
    }

    @Override
    public void selectedIndices(List<Integer> indices) {

    }

    @Override
    public void selectedStrings(List<String> strings) {
        //    Toast.makeText(context, strings.toString(), Toast.LENGTH_LONG).show();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.submit:
                Network network = new Network(context);
                if (network.isConnectedToInternet()) {
                    if (validation()) {
                        submit();
                    }
                } else {
                    network.noInternetAlertBox(getActivity(), false);
                }
                break;
            case R.id.back_button_home_activity: {
                Intent intent = new Intent(getActivity(), MapsActivity.class);
                startActivity(intent);
                Objects.requireNonNull(getActivity()).finish();
                break;
            }
            case R.id.tv_etProfile: {
                enableEdit();
                break;
            }
            case R.id.tv_cancel: {
                disableEdit();
                break;
            }
            case R.id.iv_add: {
                Bundle data = new Bundle();
                data.putString("action", "Add Service");
                AddUpdateServicesFragment fragment2 = new AddUpdateServicesFragment();
                fragment2.setArguments(data);
                FragmentManager fragmentManager = getFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.replace(R.id.frame_layout, fragment2);
                fragmentTransaction.commit();
                break;
            }
            case R.id.image:
                final CharSequence[] items = {"Take Photo", "Choose from Library",
                        "Cancel"};
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int item) {
                        if (items[item].equals("Take Photo")) {
                            cameraIntent();
                        } else if (items[item].equals("Choose from Library")) {
                            galleryIntent();

                        } else if (items[item].equals("Cancel")) {
                            dialog.dismiss();
                        }

                    }
                });
                builder.show();
                break;

//                   String s = spinner.getSelectedItemsAsString();
        }

    }

    private void cameraIntent() {
        Intent takePicture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(takePicture, 0);
    }

    private void galleryIntent() {
        Intent pickPhoto = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(pickPhoto, 1);
//        startActivityForResult(Intent.createChooser(intent, "Select File"),SELECT_FILE);
    }


    public void onActivityResult(int requestCode, int resultCode, Intent imageReturnedIntent) {
        super.onActivityResult(requestCode, resultCode, imageReturnedIntent);
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case 0:
                    Bundle extras = imageReturnedIntent.getExtras();
                    Bitmap imageBitmap = (Bitmap) extras.get("data");
                    image.setImageBitmap(imageBitmap);
                    break;
                case 1:
                    Uri selectedImage2 = imageReturnedIntent.getData();
                    image.setImageURI(selectedImage2);
                    break;
            }
        }
    }

    private void submit() {
        Intent intent = new Intent(context, HomeActivity.class);
        startActivity(intent);
        Objects.requireNonNull(getActivity()).finish();
    }

    ///////////////Screen Validation, it will return true if user has fielded all required details/////////////
    private boolean validation() {
        if (name.getText().toString().isEmpty()) {
            Snackbar.make(view, "Please Enter Name", Snackbar.LENGTH_LONG).show();
            return false;
        } else if (email.getText().toString().isEmpty()) {
            Snackbar.make(view, "Please Enter Email Id", Snackbar.LENGTH_LONG).show();
            return false;
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email.getText().toString()).matches()) {
            Snackbar.make(view, "Please Enter a Valid Email Id", Snackbar.LENGTH_LONG).show();
            return false;
        } else if (et_mobile_number.getText().toString().isEmpty()) {
            Snackbar.make(view, "Please Enter Mobile Number", Snackbar.LENGTH_LONG).show();
            return false;
        } else if (et_mobile_number.getText().toString().length() < 10) {
            Snackbar.make(view, "Please Enter a Valid Mobile Number", Snackbar.LENGTH_LONG).show();
            return false;
        }

        return true;
    }

}
