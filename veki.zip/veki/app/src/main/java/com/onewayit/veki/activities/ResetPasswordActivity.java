package com.onewayit.veki.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.onewayit.veki.R;


public class ResetPasswordActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resetpassword);
        // initViews();
    }


    private void initViews() {


    }


}


