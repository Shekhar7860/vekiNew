package com.onewayit.veki.utilities;

import java.util.HashMap;

public interface FastScrollRecyclerViewInterface {
    HashMap<String, Integer> getMapIndex();
}
